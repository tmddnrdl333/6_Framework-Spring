package com.ssafy.hw.goodver;

public class HiMsgKor implements HiMsg {
	@Override
	public String Hi(String name) {
		return "하위 " + name + "?";
	}

}
