package com.ssafy.hw.badver;

public class HiMsgKor {
	public String HiKor(String name) {
		return "하위 " + name + "?";
	}
}
