package com.ssafy.hw.goodver;

public interface HiMsg {
	public String Hi(String name);
}
