package com.ssafy.hw.goodver;

public class HiMsgEng implements HiMsg {
	@Override
	public String Hi(String name) {
		return "Hi " + name + "?";
	}

}
