package com.ssafy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookappBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
