package com.ssafy.hw.badver;

public class HiMsgEng {
	public String HiEng(String name) {
		return "Hi " + name + "?";
	}
}
